Justificativas 

1 - Introduzi definindo uma variável inteira, n1 = 1, para o programa iniciar. Logo após introduzi o enquanto para enquanto o número digitado para a variável n1 for maior que 0, a ordem de incerir um número continue se repetindo. Dentro do enquanto ocorre uma divisão do número do usuário por 2 para ver se ele é par ou não, se o número for par, isso será afirmado, senão será informado que o número incerido não é par.

2- introduzi a variável n1, n2 e n3 para serem usadas para perguntar os números e realizar a divisão, o programa verifica os números e realiza a divisão, logo após exibe os resultados.

3 - introduzi a variável n1 = 1, o programa verifica o número e ve se ele está dentro de intervalo de 10 a 50. o programa não funciona se o número for menor que 0.

4 -introduzi somente a variável n1 e com o enquanto o número que o usuário colocou é decrescido até 0, de 1 por 1.

5 - com as variáveis inteiras, senha e n2 o programa pede a senha e a define, porém realiza uma segunda camada para confirmar a senha, o programa não confirma a senha até o usuário incerir a senha correta que ele colocou antes.

6 - o programa por meio da variável n1, pede um número e mostra por meio de fórmulas toda a tabuada dele de 1 a 10.

7 - O programa por meio da variável cadeia, letra, pede a letra e com a utilização da fórmula ele verifica se é vogal ou consoante.

8 - com as variáveis reais, peso, altura e imc, o programa coleta as informações realiza os calculos por meio de formulas e fórmulas já existentes e apresenta o imc.

9 - o programa pede números de forma indefinida até que o usuário insira um número negativo, quando ele insere o programa finaliza e exibe a soma de todos os números pares citados pelo usuário.

10 - O usuário incere a idade e o programa catalóga ela na variável idade, inteira, e por meio do enquanto, o programa verifica se a idade colocada é maior ou menor que 18.
